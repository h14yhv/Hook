*********************************************
DO NOT CLOSE THIS WINDOW
*********************************************

This window serves as a point of reference for
this dock.  If you close it, other windows may
not know where to position themselves.

If you want to tab another window against this
dock, it is recommended that you first bring 
this placeholder to the front of the dock.