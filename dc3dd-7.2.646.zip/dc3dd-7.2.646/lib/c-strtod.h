double c_strtod (char const *, char **);
long double c_strtold (char const *, char **);
