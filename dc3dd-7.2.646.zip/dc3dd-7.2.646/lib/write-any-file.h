#include <stdbool.h>
bool can_write_any_file (void);
