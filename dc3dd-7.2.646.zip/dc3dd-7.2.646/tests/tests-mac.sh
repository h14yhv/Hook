#!/bin/bash
   
   ./test-compile.sh mac \
&& ./test-file-imaging.sh \
&& ./test-hashing.sh \

